import { UserState, Transaction } from '../types';

const STORAGE_KEY = 'moneypaws_app_state_v2';

const INITIAL_TRANSACTIONS: Transaction[] = [
  {
    id: 'tx-1',
    type: 'MINE_TAP',
    amountPhp: 0.15,
    title: 'Tap to Mine - Paw Power Bonus',
    timestamp: Date.now() - 1000 * 60 * 20,
    status: 'COMPLETED',
  },
  {
    id: 'tx-2',
    type: 'DAILY_LOGIN',
    amountPhp: 0.50,
    title: 'Day 1 Daily Login Reward',
    timestamp: Date.now() - 1000 * 60 * 60 * 3,
    status: 'COMPLETED',
  },
];

export const DEFAULT_USER_STATE: UserState = {
  balancePhp: 0.65, // Exactly matching screenshot "₱0.65"
  targetThresholdPhp: 5.50, // Matches screenshot "Next Target Threshold: P.65/ 5.500"
  totalEarnedPhp: 0.65,
  tapMineCount: 14,
  stepsToday: 1240,
  stepsGoal: 5000,
  gamesPlayedToday: 1,
  claimedMissionIds: [],
  minerBatteryPercent: 88,
  minerLastClaimed: Date.now() - 1000 * 60 * 15,
  consecutiveDays: 1,
  lastCheckinDate: '',
  lastLuckyChestDate: '',
  freeSpins: 3,
  freeScratchCards: 3,
  adsWatchedToday: 0,
  referralCode: 'PAW-ANDROID77',
  referralCount: 1,
  referralEarningsPhp: 0.20,
  transactions: INITIAL_TRANSACTIONS,
  tickets: [],
  soundEnabled: true,
  userName: 'Paws Explorer',
  userEmail: 'user@moneypaws.com',
};

export function loadUserState(): UserState {
  if (typeof window === 'undefined') return DEFAULT_USER_STATE;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_USER_STATE;
    const parsed = JSON.parse(raw);
    return {
      ...DEFAULT_USER_STATE,
      ...parsed,
    };
  } catch (err) {
    console.warn('Failed to load user state from localStorage:', err);
    return DEFAULT_USER_STATE;
  }
}

export function saveUserState(state: UserState): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (err) {
    console.warn('Failed to save user state:', err);
  }
}

export function formatPhp(amount: number): string {
  // Format matching the screenshot style: ₱0.65
  return `₱${amount.toFixed(2)}`;
}

export function formatPaws(paws: number): string {
  return paws.toLocaleString('en-US');
}

export function formatUsd(paws: number): string {
  const usd = paws / 1000;
  return `$${usd.toFixed(2)}`;
}


